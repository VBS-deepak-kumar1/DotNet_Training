﻿using System;

namespace DeepCopy_ShallowCopy
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Deep Copying taking place as memory ");

            ShallowCopy obj = new ShallowCopy();
            ShallowCopy objClone = obj;
            obj.I = 101;//setting obj value after cloning
            Console.WriteLine("objvalue:{0}\t Clone Value:{1}", obj.I, objClone.I);



            Console.WriteLine("______After Implementing Shallow Copying using Clone()_________");

            ShallowCopy obj2 = (ShallowCopy)obj.Clone();

            obj.I = 201;

            Console.WriteLine("After using MemberWiSeClone() : {0} ", obj2.I);

        }
    }
}
