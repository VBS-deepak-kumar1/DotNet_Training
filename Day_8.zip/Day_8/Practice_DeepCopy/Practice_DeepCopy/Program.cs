﻿using System;


namespace Practice_DeepCopy
{
    class ReferenceType
    {
        public int RFT { get; set; }
    }
    class ShallowCopy : ICloneable
    {
        public int I { get; set; }
        public int J { get; set; }
        public ReferenceType K = new ReferenceType();
        //method updated for reference type....
        public object Clone()
        {
            //Shallow Copy..
            ShallowCopy SC = (ShallowCopy)this.MemberwiseClone();
            //Deep Copy..
            ReferenceType RT = new ReferenceType();
            RT.RFT = this.K.RFT;
            SC.K = RT;
            return SC;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            ShallowCopy obj = new ShallowCopy();
            obj.K.RFT = 100;
            ShallowCopy objClone = (ShallowCopy)obj.Clone();
            obj.K.RFT = 200;//make changes in obj.
            Console.WriteLine(objClone.K.RFT);
            Console.ReadKey();


        }
    }
}
