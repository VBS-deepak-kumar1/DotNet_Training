﻿using System;

namespace Practice_ShallowCopy
{
    class ShallowCopy
    {
        public int I { get; set; }
        public int J { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Shallow Copy Implementation..");
            ShallowCopy obj = new ShallowCopy();
            ShallowCopy objClone = obj;
            obj.I = 170;//setting obj value after cloning..
            Console.WriteLine("objvalue : {0} \t Clone value :{1}",obj.I=12,objClone.I);
            Console.ReadKey();
            /*Surprise! This is not what we were looking for, right?
             * So here the MemberwiseClone() method is useful.
             * Let's change the class as in the following:
             filename or folder name practice2_ShallowCopy*/
        }
    }
}
