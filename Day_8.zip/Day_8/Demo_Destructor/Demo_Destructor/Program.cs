﻿using System;

namespace Demo_Destructor
{
    internal class Complex {
        int real, imaginary;
        public Complex()
        {
            real = 0;
            imaginary = 0;
        }
        public void SetValue(int r, int i)
        {
            real = r;
            imaginary = i;
        }
        public void Display()
        {
            Console.WriteLine(real);
            Console.WriteLine(imaginary);
        }
        ~Complex()
        {
            Console.WriteLine("Destructor was called");
        }
    }

    class Program
    {
        public static void CallObj()
        {
            Complex C = new Complex();


        }
        static void Main(string[] args)
        {
            CallObj();
            GC.Collect();
           
        }
    }
}
