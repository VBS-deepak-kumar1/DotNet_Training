﻿using System;
using System.IO;
namespace Practice_FileHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with streams");
            FileWrite wr = new FileWrite();
            wr.WriteData();
            Console.WriteLine("Reading Data from the file..");
            wr.ReadData();
           //Console.ReadKey();
        }
    }
}
