﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Practice_FileHandling
{
    class FileWrite
    {
        public string url = @"C:\Users\Deepak Kumar\source\repos\Practice_FileHandling\Practice_FileHandling\WriteDetails.txt";
       public void WriteData()
        {
            FileStream fs = new FileStream("C:\\Users\\Deepak Kumar\\source\\repos\\Practice_FileHandling\\Practice_FileHandling\\WriteDetails.txt",FileMode.Append,FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            Console.WriteLine("Enter The Text :");
            string str = Console.ReadLine();
            sw.WriteLine(str);
            sw.Flush();
            sw.Close();
            fs.Close();
        }
        public void ReadData()
        {
            FileStream fs = new FileStream(url, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string str = sr.ReadLine();
            Console.WriteLine(str);
            sr.Close();
            fs.Close();
        }
    }
}
