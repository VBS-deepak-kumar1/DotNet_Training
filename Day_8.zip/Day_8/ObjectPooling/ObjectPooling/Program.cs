﻿using System;

namespace ObjectPooling
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //Console.WriteLine("Hello World!");
            Factory fa = new Factory();
            Employee myEmp = fa.GetEmployee();
            Console.WriteLine("First Object is created..!!");
           Employee MyEmp1 =fa.GetEmployee();
            Console.WriteLine("Second Object is created..!!");
             Employee myemp2 = fa.GetEmployee();
             Console.WriteLine("third object is created..!!");
            Employee myemp3 = fa.GetEmployee();
            Console.WriteLine("forth object is created..!!");
            Console.ReadKey();
        }
    }
}
