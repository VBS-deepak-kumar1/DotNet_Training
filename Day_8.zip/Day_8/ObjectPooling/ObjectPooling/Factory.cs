﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ObjectPooling
{
    class Factory
    {
        private static int _PoolMaxSize = 2;
        private static readonly Queue ObjPool = new Queue(_PoolMaxSize);
    public Employee GetEmployee()
        {
            Employee OEmployee = new Employee();
            if(Employee.Counter>=_PoolMaxSize&& ObjPool.Count > 0)
            {
                OEmployee = RetriveFromPool();

            }
            else
            {
                OEmployee = GetNewEmployee();
            }
            return OEmployee;
        }
        protected Employee RetriveFromPool()
        {
            Employee OEmp;
            //if there is may object in my collection
            if (ObjPool.Count > 0)
            {
                OEmp =(Employee) ObjPool.Dequeue();
                Employee.Counter--;
            }
            else
            {
                //returning a new Object
                OEmp = new Employee();
            }
            return (OEmp);
        }
        private Employee GetNewEmployee()
        {
            //Creating a new employee
            Employee OEmp = new Employee();
            ObjPool.Enqueue(OEmp);
            return OEmp;
        }
    }
    class Employee
    {
        public static int Counter = 0;
        public Employee()
        {
            ++Counter;
        }
        private string _Firstname;
        public string FirstName
        {
            get
            {
                return _Firstname;
                   
            }
            set
            {
                _Firstname = value;
            }
        }

    }
}
