﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Memory_Management
{
   internal class Complex
    {
        int real, imaginary;
        public Complex()
        {
            real = 0;
            imaginary = 0;
        }
        public void SetValue(int r,int i)
        {
            real = r;
            imaginary = i;
        }
        public void Display()
        {
            Console.WriteLine(real);
            Console.WriteLine(imaginary);
        }
        ~Complex()
        {
            Console.WriteLine("Destructor was called");
        }
    }
}
