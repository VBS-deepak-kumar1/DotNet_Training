﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Memory_Management
{
    class Program
    {
        static void Main(string[] args)
        {
            Complex C = new Complex();
            C.SetValue(4, 7);
            C.Display();
           
            Console.WriteLine("End of the code");
            Console.ReadKey();
          //  GC.Collect();
          //  Console.ReadLine();

        }
    }
}
