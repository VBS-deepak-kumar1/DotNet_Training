﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_With_this
{
    public class Employee
    {
        public int id;
        public String name;
        public float salary;
        public Employee( int id,String name,float salary)
        {
            this.id = id;
            this.name = name;
            this.salary = salary;
        }
        public void Display()
        {
            Console.WriteLine(id + " " + name + " " + salary);
        }
        public static void Main(string[] args)
        {
            Employee E1 = new Employee(1, "Deepak", 3408);
            E1.Display();

            Console.ReadKey();
        }
    }
    
}
