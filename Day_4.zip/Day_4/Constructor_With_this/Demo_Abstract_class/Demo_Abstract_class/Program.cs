﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Abstract_class
{
    class Program
    {
        static void Main(string[] args)
        {
            Dog mydog = new Dog();
            mydog.No_of_Kids = 0;
            mydog.Weight();
            mydog.Age();

        }
    }
}
