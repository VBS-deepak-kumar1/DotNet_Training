﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Abstract_class
{
    interface IDomesticAniaml
    {
        //we cant define data memebers.
        //All methods are by default abstract and public
        public string  colortype();
        void NoLegs();
        void Weight();
        void Age();
        void Food_Type();
        public int No_of_Kids { get; set; }
    }
    abstract class Animal
    {
        public abstract void Speak();
        //{
        //we cant provide function definition or body.
        // Console.WriteLine("testing");
        //}
        public void AnimalLanguage()
        {
            Console.WriteLine("ZZZ..ZZZ...ZZZZ");
        }
    }

    class Dog : Animal
    {
        public override void Speak()
        {
            Console.WriteLine("The Dog Says:Woof Woof");
        }
    }
    class Cat : Animal
    {
        public override void Speak()
        {
            Console.WriteLine("The cat Says:Meaw Meaw");
        }
    }
}
