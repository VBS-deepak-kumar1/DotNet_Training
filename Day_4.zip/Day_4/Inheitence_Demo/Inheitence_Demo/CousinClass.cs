﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheitence_Demo
{
    class CousinClass:BaseClass
    {
        public CousinClass()
        {
            Console.WriteLine(" iam cousin class.");
        }
    }
}
