﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheitence_Demo
{
    class BaseClass
    {
        public string name;
        public string subject;
        public void read(string name,string subject)
        {
            this.name = name;
            this.subject = subject;
            Console.WriteLine($"I am {name} and my subject is {subject}");

        }
    }
    class Child:BaseClass
    {
        public Child ()
        {
            Console.WriteLine("this is my child class.!!1");
        }
    }

    class newchild:Child
    {
        public newchild()
        {
            Console.WriteLine("this is newhild class");
        }
    }
}
