﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheitence_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Child child1 = new Child();
            child1.read("Akshay", "Martial Arts");
            newchild C1 = new newchild();
            CousinClass cousin1 = new CousinClass();
            cousin1.read("vijay", "judo");
            Console.ReadKey();

        }
    }
}
