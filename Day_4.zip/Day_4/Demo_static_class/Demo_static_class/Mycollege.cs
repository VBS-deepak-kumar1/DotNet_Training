﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_static_class
{
    static class Mycollege
    {
        public static string CollegeName;
        public static string CollegeAddress;
        public static string CollegeCity;
        private static string year;
        //private string streams
        public static string year
        {
            get { return year; }
           set { year = value; }
        }


        public static string EstablishmentYear {get;set;}

        static Mycollege()
        {
            CollegeAddress = "bihar";
            CollegeName = "nit";
            CollegeCity = "patna";

        }

    }
}
