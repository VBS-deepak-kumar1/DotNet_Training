﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_static_class
{
    class Program
    {
        static void Main(string[] args)
        {
            //we dont need to create any object
            //static functions can be called from other functions directly. 
            Console.WriteLine(Mycollege.CollegeName);
            Console.WriteLine(Mycollege.CollegeCity);
            Console.WriteLine(Mycollege.CollegeAddress);
            Mycollege.EstablishmentYear = "1998";
            Console.WriteLine(Mycollege.EstablishmentYear + " is the year of establishment");

            Console.ReadKey();
        }
    }
}
