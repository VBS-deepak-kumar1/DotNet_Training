﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Properties
{
    class Student
    {
        private string[] names = new string[25];//An Array of strings
        public string this [int i]
        {
            get { return names[i]; }
            set { names[i] = value; }
        }

        public int AdharCardNo 
        { 
            get { return 676567; }//Read Only Property
        }
        public int Id { get; set; }//In this implementation,private field is automatically declared.
        private string faceBookLink;//private field
        private string name;//private field
        public string Name //Defining Property
        { 
            get { return name; }
            set { name = value; }
        }

        public Student(string name,int Id )
        {
            this.name = name;
            this.Id = Id;
        }
    }
}
