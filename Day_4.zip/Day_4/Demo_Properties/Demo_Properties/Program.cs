﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Properties
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Implementing Properties.");
            Student newStudent = new Student("Karan",2);
            //newStudent.Id = 1;
            //newStudent.Name = "Aman";
            //newStudent.AdharCardNo = "4567";
                

            Console.WriteLine($"Student Id : {newStudent.Id} & Student Name : {newStudent.Name} , Card details:{newStudent.AdharCardNo}");
            newStudent[0] = "Yami";
            newStudent[1] = "Peter";
            newStudent[2] = "Parker";
            for(int i = 0; i <4; i++)
            {
                Console.WriteLine(newStudent[i]);
            }
           /* foreach(var item in newStudent[])
            {
                Console.WriteLine(newStudent[item]);
            }*/



            Console.ReadKey();
        }
    }
}
