﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Base_Keyword
{
    public class Animal
    {
        public string color = "yellow";
        public virtual void Speak()
        {
            Console.WriteLine("Animal Speak from their heart!!..");
        }

    }
    public class Dog:Animal
    {
        public string color = "black";
        public override void Speak()
        {
            Console.WriteLine("Dog Speak from their heart!!..");
            Console.WriteLine($"base in dog class speak says");
            //base.Speak();
        }
        public void Showcolor()
        {
            Console.WriteLine($"Color Coming from baseclass {base.color}");
            Console.WriteLine($"Color Coming from childclass {color}");

        }
    }
}
