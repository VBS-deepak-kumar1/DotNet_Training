﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Base_Keyword
{
    class Program
    {
        static void Main(string[] args)
        {
            Dog ginger = new Dog();
            ginger.Showcolor();
            ginger.Speak();
            Console.ReadKey();
                
        }
    }
}
