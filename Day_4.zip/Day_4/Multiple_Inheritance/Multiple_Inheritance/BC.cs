﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiple_Inheritance
{
    interface IBC
    {
        int add(int a, int b);
        int subtract(int a, int b);
    }
    interface IScientificCalc
    {
        float add(float a, float b);
        float subtract(float a, float b);

    }
    class Calculation : IBC, IScientificCalc
    {
        public int add(int a,int b)
        {
            Console.WriteLine("This is Add() Coming from BC.");
            return a + b;
        }

        public float add(float a, float b)
        {
            //throw new NotImplementedException();
            Console.WriteLine("This is Add() Coming from SC.");
            return a + b;
        }

        public int subtract(int a,int b) 
        { 
             Console.WriteLine("This is subtract() Coming from BC.");
            return a - b;
        }

        public float subtract(float a, float b)
        {
            //throw new NotImplementedException();
            Console.WriteLine("This is subtract() Coming from SC.");
            return a - b;
        }
    }
}
