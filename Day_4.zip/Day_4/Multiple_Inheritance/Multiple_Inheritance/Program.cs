﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiple_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculation C1 = new Calculation();
           Console.WriteLine( C1.add(5, 6));
            Console.WriteLine(C1.add(5.4f, 6.8f));
            Console.WriteLine(C1.subtract(5, 6));
            Console.WriteLine(C1.subtract(5.4f, 6.8f));
            Console.ReadKey();

        }
    }
}
