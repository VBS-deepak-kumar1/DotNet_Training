﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using  System.Data.SqlClient;

namespace DataGrid
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void filldata_Click(object sender, EventArgs e)
        {
            
            string ConnString = "Data Source={server name};Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=*********";
            SqlConnection connection = new SqlConnection(ConnString);
            connection.Open();
            string querystring = "Select * from deepak_employee";
            SqlDataAdapter adapter = new SqlDataAdapter(querystring, connection);
            DataTable d = new DataTable("employee");
            adapter.Fill(d);
            dataGridView1.DataSource = d;
            dataGridView2.DataSource = d;
            connection.Dispose();
            connection.Close();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
