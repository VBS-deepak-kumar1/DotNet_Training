﻿using System;
using System.Collections.Generic;
using System.Linq;//provides classes and interfaces that support LINQ queries..
using System.Text;
using System.Threading.Tasks;

namespace Demo_LINQ_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[] { 1, 2, 3, 6, 8, 34 };
            var result = from a
                         in num
                         where a <=8
                         orderby a
                         select a;
            foreach(var item in result)
            {
                Console.WriteLine(item);
            }

        }
    }
}
