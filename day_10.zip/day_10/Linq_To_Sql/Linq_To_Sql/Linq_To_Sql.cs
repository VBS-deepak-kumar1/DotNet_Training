﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Data.Linq.Mapping;

namespace Linq_To_Sql
{
   

    public partial class Linq_To_Sql : Form
    {
        public Linq_To_Sql()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Linq_To_Sql_Load(object sender, EventArgs e)
        {
            string Connstring = "Data Source={server name};Initial Catalog=AdventureWorks2017;Persist Security Info=True;User ID=trainee2022;Password=***********";
            try
            {
                //Creating data Context..
                DataContext db = new DataContext(Connstring);
                Table<Contact> contacts = db.GetTable<Contact>();//Returns  table of similar type
                                                                 //Query DB
                var contactDetails = from c in contacts
                                     where c.Title == "Mr."
                                     orderby c.FirstName
                                     select c;
                //Display Contact details 
                foreach (var c in contactDetails)
                {
                    textBox1.AppendText(c.Title + "  ");
                    textBox1.AppendText("\t");
                    textBox1.AppendText(c.FirstName + "  ");
                    textBox1.AppendText("\t");

                    textBox1.AppendText(c.LastName + "  ");
                   textBox1.AppendText("\n\n"); textBox1.AppendText("\n");
                    textBox1.AppendText("\t\t");

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

                                                             

        }
    }
    [Table(Name ="Person.Person")]
    public class Contact
    {
        [Column]
        public string Title;
        [Column]
        public string FirstName;
        [Column]
        public string LastName;
    }

}
