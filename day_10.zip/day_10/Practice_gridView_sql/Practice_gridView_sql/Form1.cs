﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Practice_gridView_sql
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Connstring = "Data Source={server name};Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=*********";
            SqlConnection connection = new SqlConnection(Connstring);
            connection.Open();
            string queryString = "select * from deepak_Organization";
            SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
            DataTable d = new DataTable("org_table");
            adapter.Fill(d);
            dataGridView1.DataSource = d;
            connection.Dispose();
            connection.Close();


        }
    }
}
