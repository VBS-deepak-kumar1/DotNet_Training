﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Demo_ADO.NET
{
    class Program
    {
        static void Main(string[] args)
        {
            string ConString = "Data Source={server name};Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=*********";
            SqlConnection conn = new SqlConnection(ConString);
            string queery = "select * from deepak_Persons";
            conn.Open();
            SqlCommand cmd = new SqlCommand(queery, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    Console.Write(reader[i] + " ");

                }
                Console.WriteLine(" ");
            }
            Console.ReadKey();
        }

    }
}
       
