﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;


namespace Practice_Serialization
{
    class Program
    {
        static void Main(string[] args)
        {
            string Path = @"C:\Users\Deepak Kumar\source\repos\Practice_Serialization\Practice_Serialization\practice.txt";
            FileStream stream = new FileStream(Path, FileMode.OpenOrCreate);
            //BinaryFormatter formatter = new BinaryFormatter();
            IFormatter formatter = new BinaryFormatter();
            Student s = new Student("101", "Deepak  Bhagat");
            formatter.Serialize(stream, s);
            stream.Close();
            Console.WriteLine("----------------");
            FileStream stream1 = new FileStream(Path,FileMode.OpenOrCreate);
            BinaryFormatter formatter1 = new BinaryFormatter();

            Student s1 = (Student)formatter1.Deserialize(stream1);
            Console.WriteLine("Rollno: " + s1.rollno);
            Console.WriteLine("Name: " + s1.name);

            stream.Close();
            Console.ReadKey();

        }
    }
}
