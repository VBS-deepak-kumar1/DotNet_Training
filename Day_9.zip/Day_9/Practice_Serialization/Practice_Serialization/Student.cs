﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;



namespace Practice_Serialization
{
    [Serializable]
    class Student
    {
      public  string rollno;
      public  string name;
        public Student(string rollno,string name)
        {
            this.rollno = rollno;
            this.name = name;
        }
    }
}
