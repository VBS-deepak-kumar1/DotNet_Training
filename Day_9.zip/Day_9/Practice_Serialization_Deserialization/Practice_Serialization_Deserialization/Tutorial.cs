﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_Serialization_Deserialization
{ 
    [Serializable]//Declarative tag is used for adding meta data.
    class Tutorial
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
