﻿using System;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Linq;



namespace Practice_Serialization_Deserialization
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Serialization And Deserialization  implementation...!!");
            Tutorial obj = new Tutorial();
            obj.ID = 1;
            obj.Name = "ASP.NET MVC";
            string Path = @"c:\users\deepak kumar\source\repos\day_9\practice_serialization_deserialization\Practice_Serialization_Deserialization\demo1.txt";
            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream(Path, FileMode.Create, FileAccess.Write);
            //serializing object
            formatter.Serialize(stream, obj);
            Console.WriteLine("object has been serialized...!!!");
           stream.Close(); Stream stream1 = new FileStream(Path, FileMode.Open, FileAccess.Read);
           Tutorial objNew = (Tutorial)formatter.Deserialize(stream1);
            Console.WriteLine(objNew.ID);
          Console.WriteLine(objNew.Name);
            Console.WriteLine("Data After Deserilization..!!");
            stream1.Close();
            Console.ReadKey();

        }
    }
}
