﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Demo1_Multithreading
{
    class Program
    {
        static void Print()
        {
            for (int i=0; i < 10; i++){
                Console.WriteLine("Other Thread : {0}", i);
                Thread.Sleep(1000);
            }
        }
        static void Main(string[] args)
        {
            Thread th;
            th = Thread.CurrentThread;
            Thread th1 = new Thread(Program.Print);
            th1.Start();
            Console.WriteLine(" Thread State : {0} ",th1.ThreadState);
            Console.WriteLine(" Thread IsAlive before  : {0} ", th1.IsAlive);
           
            Console.WriteLine("Thraed Suspend");
            th1.Suspend();
            Console.WriteLine(" Thread State : {0} ", th1.ThreadState);
            Console.WriteLine(" Thread isAlive After : {0} ", th1.IsAlive);
            Console.WriteLine("Thraed Resume");
            th1.Resume();
            Console.WriteLine(" Thread State : {0} ", th1.ThreadState);
            Console.WriteLine(" Thread isAlive After : {0} ", th1.IsAlive);
           // Console.WriteLine("Thread Abort");
          //  th1.Abort();
         //   Console.WriteLine(" Thread State : {0} ", th1.ThreadState);
          //  Console.WriteLine(" Thread isAlive After : {0} ", th1.IsAlive);

            Console.ReadKey();
        }
    }
}
