﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Practice_MultiThreading
{
    public class Mythread
    {
        public static void Thread1Display()
        {
            for(int i = 0; i < 3; i++)
            {
                Console.WriteLine("First thread : {0}", i);
            }
        }
        public static void Thread2Display()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Second thread : {0}", i);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Multithreading..");
            //Mythread obj = new Mythread();
            Thread th1 = new Thread(Mythread.Thread1Display);
            Thread th2 = new Thread(Mythread.Thread2Display);
            th1.Start();
            th2.Start();
            Console.WriteLine("line 1");
            Console.ReadKey();
        }
    }
}
