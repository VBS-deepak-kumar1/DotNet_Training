﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Practice_FileStreamClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("C# FileStream Writing single byte into file..!");
            string path = @"C:\Users\Deepak Kumar\source\repos\Practice_FileStreamClass\Practice_FileStreamClass\fstream.txt";
            FileStream fs = new FileStream(path, FileMode.OpenOrCreate);
            fs.WriteByte(65);
            fs.Close();
            Console.ReadKey();

        }
    }
}
