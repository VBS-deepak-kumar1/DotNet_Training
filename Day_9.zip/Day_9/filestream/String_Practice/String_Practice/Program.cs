﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;



namespace String_Practice
{
    class Filewrite
    {
        string Path = @"C:\Users\Deepak Kumar\source\repos\String_Practice\String_Practice\filestream.txt";
        public void WriteData()
        {
            FileStream fs = new FileStream(Path, FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            Console.WriteLine("Enter the Text :");
            string str = Console.ReadLine();
            sw.WriteLine(str);
            sw.Flush();
            sw.Close();
            fs.Close();
        }
        public void ReadData()
        {
            FileStream fs = new FileStream(Path,FileMode.Open,FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string str = sr.ReadLine();
            Console.WriteLine(str);
            sr.Close();
            fs.Close();     
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("working with stream...");
            Filewrite fw = new Filewrite();
            fw.WriteData();
            Console.WriteLine("Reading data from the file...");
            fw.ReadData();
            Console.ReadKey();
        }
    }
}
