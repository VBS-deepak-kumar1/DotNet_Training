﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;


namespace Demo_SortedList
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SortedList mysortedlist = new SortedList();
            mysortedlist.Add(5, "Deepak");
            mysortedlist.Add(3, "Neeraj");
            mysortedlist.Add(1, "Rani");
            mysortedlist.Add(4, "Aman");
            mysortedlist.Add(2, "Raju");
            mysortedlist.Add(6, "Rahul");
            mysortedlist.Add(7, "Juhi");
            
            foreach(DictionaryEntry item in mysortedlist)

            {
                Console.WriteLine("{0}--->{1}",item.Key,item.Value);
            }


            Console.ReadLine();

        }
    }
}
