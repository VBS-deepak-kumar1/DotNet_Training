﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fuctionOverLoad
{
    class Program
    {
        static int Add(int x,int y)
        {
            return x + y;
        }
        static float Add(float a,float b)
        {
            return a + b;
        }
        static string Add(string s1,string s2)
        {
            return s1 + s2;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Function OverLoading.");
            Console.WriteLine("callint INT based add function :"+Add(12, 34));
            Console.WriteLine("callint FLOAT based add function :"+Add(12.5f, 34.7f));
            Console.WriteLine("callint string based add function :"+Add("deepak", "kumar"));
            Console.ReadKey();
        }
        
    }
}
