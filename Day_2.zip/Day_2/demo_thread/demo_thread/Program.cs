﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Threading;


namespace demo_thread
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*CultureInfo cultureculture = Thread.CurrentThread.CurrentCulture;
            Calendar c1=cultureculture.Calendar;
            Calendar mycalender = new HijriCalendar();
            DateTime dt = new DateTime(2022, 01, 09, mycalender);*/

            Console.WriteLine("Using thread for displaying time in a loop.");
            for(int i = 0; i < 20; i++)
            {
                Console.WriteLine(DateTime.Now);
                Thread.Sleep(1000);

            }
            Console.WriteLine(DateTime.Now);

        }
    }
}
