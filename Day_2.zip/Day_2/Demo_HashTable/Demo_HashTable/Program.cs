﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;



namespace Demo_HashTable
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hash Table Implemetation - Non Genric Collection Class");
            Hashtable myht = new Hashtable();
            myht.Add(1,"TOM CRUISE");
            myht.Add(2,"TOM HIDD");
            myht.Add(3,"TOM FURY");
           foreach(DictionaryEntry item in myht)
            {
                Console.WriteLine($"key:{item.key},value:{item.Value}");
            }
        }
    }
}
