﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_List_Collection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //list is a generic collection.
            Console.WriteLine("Implementing Generic List Collection.");
            //Creating list using List class and 
            //List<T>() Constructor
            List<string> movies = new List<string>();
           // var movies=new List<string>();
           // Console.WriteLine(movies.Capacity);
           // Console.WriteLine(movies.Count);
            movies.Add("End Game");
            movies.Add("John Wick");
            movies.Add("Tenet");
            movies.Add("Avengers");
            movies.Add("Captain America");
            movies.Add("Captain Marvel");
           movies.Add("star wars");
            movies.Add("Harry Potter");
            //Console.WriteLine(movies);
            Console.WriteLine(movies.Capacity);
            Console.WriteLine(movies.Count);
            //movies.Clear();
            //movies.RemoveAt(6);

          movies.Sort();
            // movies.Reverse();
          //  movies.Reverse();

            foreach (var ele in movies){
                Console.WriteLine(ele);
            }

            //Console.WriteLine( movies.Contains("movies"));
            //movies.Remove("star wars");
            //Console.WriteLine(movies.Remove(movies[0]));
            //movies.RemoveAll(movies.)
            
         

            /*Console.WriteLine("printing elements of list movies after removal of star wars");
            for (int i = 0; i < movies.Count; i++)
            {
                Console.WriteLine(movies[i]);
            }
            Console.WriteLine("printing elements of list movies using forEach method");

            movies.ForEach(movie=>Console.WriteLine(movie));
           
            */
           

            Console.ReadKey();

        }
    }
}
