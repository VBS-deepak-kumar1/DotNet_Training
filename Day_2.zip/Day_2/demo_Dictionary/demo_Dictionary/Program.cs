﻿using System;
using System.Collections.Generic;



namespace demo_Dictionary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dictionary implementation");
           Dictionary<string, string> EmpList = new Dictionary<string, string>();
            EmpList.Add("Aman", "Programmmer");
            EmpList.Add("Avinash", "Architect");
            EmpList.Add("kartik", "Manager");
            foreach(KeyValuePair<string,string> item in EmpList)
            {
                Console.WriteLine($"{item.Key} {item.Value}");
            }
        }
    }
}
