﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dict_authorList
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, Int16> AuthorList = new Dictionary<string, Int16>();
            AuthorList.Add("Deepak", 3);
            AuthorList.Add("kumar", 5);
            AuthorList.Add("pakiya", 2);
            AuthorList.Add("saroj", 4);
            AuthorList.Add("Raju", 1);
            Console.WriteLine(AuthorList.Count);
            Console.WriteLine("displaying dict");
            
            foreach(KeyValuePair<string, Int16> item in AuthorList)
            {
                Console.WriteLine($"key : {item.Key} value : {item.Value}");
            }
            AuthorList.Remove("kumar");
            Console.WriteLine("displaying dict after removal of kumar");

            foreach (KeyValuePair<string, Int16> item in AuthorList)
            {
                Console.WriteLine($"key : {item.Key} value : {item.Value}");
            }

            AuthorList.Clear();
            Console.WriteLine(AuthorList.Count);



            Console.WriteLine("PriceList");
            Dictionary<string, float> PriceList = new Dictionary<string, float>();
            PriceList.Add("Table", 67.8f);
            PriceList.Add("fan", 45.234f);
            PriceList.Add("Cup", 6.6f);
            Console.WriteLine(PriceList.Count);
            Console.WriteLine("displaying pricelist");
            foreach (KeyValuePair<string,float> item in PriceList)
            {
                Console.WriteLine($"key : {item.Key} value : {item.Value}");
            }
            PriceList.Remove("fan");
            Console.WriteLine("displaying dict after removal of fan");

            foreach (KeyValuePair<string, float> item in PriceList)
            {
                Console.WriteLine($"key : {item.Key} value : {item.Value}");
            }

            PriceList.Clear();
            Console.WriteLine(PriceList.Count);

            Console.ReadKey();  
        }
    }
}
