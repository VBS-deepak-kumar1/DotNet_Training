﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace function_Demo
{
    class Program
    {
        static int CalSqr(int x)
        {
            return x * x;
        }
        //Named Arguments
        static void Display(string CEO,string Manager,String TestEngineer)
        {
            Console.WriteLine("Senior " + CEO);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CalSqr(12));
            Display(TestEngineer: "Tom Cruise", CEO: "Mahesh Babu", Manager: "Morgan Freeman");
            Console.ReadKey();
        }
    }
}
