﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ternary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ternary conditional  Operator");
            int x = 20, y = 10;
            var result = x > y ? "x is greater than y" : "y is greater than x";
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}
