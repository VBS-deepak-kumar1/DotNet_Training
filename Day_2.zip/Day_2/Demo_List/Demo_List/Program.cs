﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_List
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> mylist = new List<int>();
            mylist.Add(1);
            mylist.Add(20);
            mylist.Add(30);
            mylist.Add(40);
            mylist.Add(45);
            mylist.Add(46);
            mylist.Add(47);
            mylist.Add(70);
            Console.WriteLine("the number of elements in mylist is {0}",mylist.Count);
            Console.WriteLine("printing all elements of mylist List.");
            foreach (int i in mylist)
            {
                Console.WriteLine(i);
            }
            //after using Remove() method
            mylist.Remove(20);
            Console.WriteLine("now count of my list is {0}", mylist.Count);
            //after using RemoveAt() method
            mylist.RemoveAt(4);
            Console.WriteLine("now count of my list is {0}", mylist.Count);
            //after using RemoveRange() method
            mylist.RemoveRange(3, 2);
            Console.WriteLine("now count of my list is {0}", mylist.Count);
            foreach (int i in mylist)
            {
                Console.WriteLine(i);
            }
            mylist.Clear();
            Console.WriteLine("now count of my list is {0}", mylist.Count);

            Console.ReadKey();

        }
    }
}
