﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_array
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr=new int[5];
            Console.WriteLine("taking element using for loop");
            for(int i=0; i<arr.Length; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());         
            }
            Console.WriteLine(" displaying element using for loop");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
            
            Console.WriteLine("display elements using foreach loop");
            foreach (int element in arr)
            {
                Console.WriteLine(element); 
               
            }

            Console.WriteLine("sum is " +arr.Sum());
            Console.WriteLine("max is "+ arr.Max());
            Console.WriteLine("min is "+ arr.Min());
            Array.Sort(arr);
            Console.WriteLine("display elements after sorting using foreach loop");
            foreach (int element in arr)
            {
                Console.WriteLine(element);

            }





            Console.ReadKey();

        }
    }
}
