﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
namespace LInq_To_XML_App
{
    class Program
    {
        
        string Path = "C:\\Users\\Deepak Kumar\\source\\repos\\LInq_To_XML_App\\LInq_To_XML_App\\ParticipantsDetails.xml";
        private void GETXMLData() {
            //string Path = @"C:\Users\Deepak Kumar\source\repos\LInq_To_XML_App\LInq_To_XML_App\ParticipantsDetails.xml";

            XDocument doc = XDocument.Load(Path);
            // XDocument doc = XDocument.Parse(Path);
            var students = from student in doc.Descendants("Participant")
                           select new
                           {
                               ID = Convert.ToInt32(student.Attribute("ID").Value),
                               Name = student.Element("Name").Value
                           };
            // Console.WriteLine(students);
            foreach (var item in students)
            {
                Console.WriteLine(item.ID + " " + item.Name);
            }
        }
        private void InsertXMLData(string name)
        {
           // try
           // {
                XDocument myXML = XDocument.Load(Path);
                XElement newParticipant = new XElement("Participant", new XElement("Name", name));
                var LastStudent = myXML.Descendants("Participant").Last();
                int newID = Convert.ToInt32(LastStudent.Attribute("ID").Value);//it gets the ID of last element.. 
                newParticipant.SetAttributeValue("ID", newID+1);//Setting Attribute
                myXML.Element("Participants").Add(newParticipant);//Adding new element
                myXML.Save(Path);//saving changes
          

           // }
           // catch (Execption)
           // {

           // }
        }
        public void ModifyXMLData(string name,int Id,int newID)
        {
            XDocument doc = XDocument.Load(Path);
          
            var students = from student in doc.Descendants("Participant")
                           where Convert.ToInt32(student.Attribute("ID").Value) == Id
                           select student;
            foreach (var student in students)
            {
                student.Element("Name").SetValue(name);
                student.Attribute("ID").SetValue(newID);
               
                
            }
            doc.Save(Path);

        }
        public void DeleteXMLData(string name,int Id)
        {
            try
            {
                XDocument textxml = XDocument.Load(Path);
                XElement dparticipant = textxml.Descendants("Participant").Where(c => c.Attribute("ID").Value.Equals(Id.ToString())).FirstOrDefault();
                dparticipant.Remove();
               
                textxml.Save(Path);
            }
            catch(Exception e)
            {
                Console.WriteLine("Exception "+e);
            }
        }
         static void Main(string[] args)
        {
            Program obj = new Program();
            obj.GETXMLData();
            obj.InsertXMLData("arjun");
            obj.InsertXMLData("bhagat");
            obj.InsertXMLData("niku");
            Console.WriteLine("------------------------------------------------");
            obj.ModifyXMLData("Deepak", 3,1);
            obj.GETXMLData();
        }
    }
}
