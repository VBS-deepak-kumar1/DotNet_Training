﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_Typecasting
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int age = 9;
            double myDouble = age;
            Console.WriteLine(myDouble);
            Console.WriteLine(age);
            Console.WriteLine(" here int to doublke is automatically done ...!!!");

            Console.WriteLine("----------Explicit typecasting---------------------");
            double newDouble = -9.99;
            bool myBool = true;
            int newAge = (int)newDouble;
            Console.WriteLine(newAge);
            Console.WriteLine(newDouble);
            bool choice = Convert.ToBoolean(newDouble);
            Console.WriteLine(choice);
            Console.WriteLine(Convert.ToString(myBool));
            
            
        }
    }
}
