﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;//We have to Add this namespace for converting text into speech

namespace Demo_Text_to_Speech
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Step 1: Adding the reference
            //Step 2: creating the object of the clas and calling  setOutputToDefault()
            //Step 3: Calling Speak()
            Console.WriteLine("Enter Your text ehich you want to convert into speech..!!!!");
            SpeechSynthesizer spk = new SpeechSynthesizer();
            spk.SetOutputToDefaultAudioDevice();
            spk.SetOutputToWaveFile("D:\\");
            spk.Speak(Console.ReadLine());
            

        }
    }
}
