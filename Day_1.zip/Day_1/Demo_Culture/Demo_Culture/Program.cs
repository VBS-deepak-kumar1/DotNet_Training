﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Threading;

namespace Demo_Culture
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with Culture Information");
            CultureInfo culture = new CultureInfo("en-US");
            Console.WriteLine(culture.Name);

            //string currentCulture = Thread.CurrentThread..CurrentCulture.DisplayName;
            DateTime currenTime=DateTime.Now;
            string dateiUSA = currenTime.ToString("ddd", new CultureInfo("en-US"));
            Console.WriteLine(dateiUSA);
            Console.ReadKey();
        }
    }
}
