﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_DateAndTime
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Working with Date And time.");
            DateTime todayDate = new DateTime(2022,9,01,10,30,45);
            Console.WriteLine(todayDate.Year);
            Console.WriteLine(todayDate.Month);
            Console.WriteLine(todayDate.Day);
            Console.WriteLine(todayDate.Hour);
            Console.WriteLine(todayDate.Minute);
            Console.WriteLine(todayDate.Second);
            Console.WriteLine(DateTime.Now);
            Console.WriteLine(DateTime.MinValue);
            Console.WriteLine(DateTime.MaxValue);
            Console.WriteLine(todayDate.ToString("MMMM dd yyyy"));
            Console.ReadKey();
                
        }
    }
}
