﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Your Name :");
            string firstName = Console.ReadLine();
            string secondName = Console.ReadLine();
            int number = 3;
            Console.WriteLine(firstName + ' ' + secondName);
            Console.Write(number);
            Console.ReadKey();
        }
    }
}
