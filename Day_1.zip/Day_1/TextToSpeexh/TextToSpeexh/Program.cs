﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;

namespace TextToSpeexh
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Your text Which you want to convert into speech..!!!!");

            SpeechSynthesizer spk = new SpeechSynthesizer();

            spk.SetOutputToDefaultAudioDevice();



            spk.Speak(Console.ReadLine());
        }
    }
}
