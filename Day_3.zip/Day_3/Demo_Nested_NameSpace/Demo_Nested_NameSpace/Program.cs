﻿using System;
using first_name;
using first_name.second_space;


namespace first_name
{
    class A
    {
        public void func()
        {
            Console.WriteLine("Inside first_space");
        }
    }
    namespace second_space
    {
        class B
        {
            public void func1()
            {
                Console.WriteLine("Inside second_space");
            }

        }
    }

}

namespace Demo_Nested_NameSpace
{
    class Program
    {
        static void Main(string[] args)
        {
            A fc = new A();
            B sc = new B();
            fc.func();
            sc.func1();
            Console.ReadKey();
        }
    }
}
