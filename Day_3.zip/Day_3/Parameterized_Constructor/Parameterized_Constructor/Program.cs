﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameterized_Constructor
{
    class Employee
    {
        public int id;
        public string fname;
        public String sname;
        public float salary;
        public Employee(int i,string fn,String sn,float s)
        {
            id = i;
            fname = fn;
            sname = sn;
            salary = s;
        }
        public Employee()
        {
            Console.WriteLine("Constructor invoked.");

        }
        ~Employee()////Destructor not working here why?
        {
            Console.WriteLine("Destructor Invoked.");
        }
        public void display()
        {
            Console.WriteLine(id + " " + fname + " " + sname + " " + salary);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee E1 = new Employee(1, "Deepak", "Kumar", 4000);
            Employee E2 = new Employee(2, "Raju", "Bhai", 3000);
            Employee E3 = new Employee();
            E1.display();
            E2.display();
            Console.ReadKey();


        }
    }
}
