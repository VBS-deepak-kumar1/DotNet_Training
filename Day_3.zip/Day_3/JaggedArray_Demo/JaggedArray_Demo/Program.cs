﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArray_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[][] myarr = new int[3][];
            myarr[0] = new int[4] {11,21,31,41};
            myarr[1] = new int[6] {12,22,32,42,52,62};
            myarr[2] = new int[] { 13, 14, 5, 16, 17, 1819, 19, 20 };
            foreach(var item in myarr)
            {
                foreach(var ele in item)
                {
                    Console.Write(ele + " ");
                }
                Console.WriteLine();
            }

            for (var i=0;i<myarr.Length;i++)
            {
                for (var j=0;j<myarr[i].Length;j++)
                {
                    Console.Write(myarr[i][j] + " ");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
