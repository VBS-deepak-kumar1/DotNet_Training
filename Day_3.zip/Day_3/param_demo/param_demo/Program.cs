﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace param_demo
{
    internal class Program
    {
        public void Show(params int[] val)
        {
            for (int i = 0; i < val.Length; i++)
            {
                Console.WriteLine(val[i]);
            }
        }
        public void Display(params  object[] val)
            {
            foreach (object o in val)
            Console.WriteLine(o);
            }
        static void Main(string[] args)
        {
            Console.WriteLine("PARAM keyword ");
            Program myData=new Program();   
            myData.Show(9,8,8,6,74,4,2,3,1,4,6,7);
            Program newData=new Program();
            newData.Show(6, 7, 6, 7);
        Program newObj=new Program();
        newObj.Display("deepak", 23, "deep@gmail.com", "bihar");

        }
    }
}
