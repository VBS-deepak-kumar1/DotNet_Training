﻿using System;

namespace classDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine(Math.Abs(-21474848));
            demo obj1 = new demo();
            Console.WriteLine(obj1.wel);
            Console.ReadKey();

        }
    }
    class demo
    {
        public string wel ="demo class examples";
    }
}
