﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_Abstract_class_Method
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
