﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_String
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("string implementation");
            string str = "TEST";
            char[] charArray = { 'T', 'E', 'S', 'T' };
            Console.WriteLine(str.CompareTo(charArray.ToString()));
            Console.WriteLine(str.Equals(charArray.ToString()));
        }
    }
}
