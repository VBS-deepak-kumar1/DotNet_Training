﻿using System;

namespace Demo_Access_modifier
{
    public class MyClass
    {
        public void GetPublic() { };
        private void GetPrivate() { };
        internal void GetInternal() { };
        protected void GetProtected() { };
        protected internal void GetProtectedInternal() { };
        protected private void GetprivateProtected() { };



    }
}
