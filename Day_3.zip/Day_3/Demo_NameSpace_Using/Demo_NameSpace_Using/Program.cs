﻿using System;
using first_space;
using second_space;


namespace first_space
{
    class A
    {
        public void func()
        {
            Console.WriteLine("Inside first_space");
        }
    }
}
namespace second_space
{
    class B
    {
        public void func()
        {
            Console.WriteLine("Inside second_space");
        }
    }
}


namespace Demo_NameSpace_Using
{
    class Program
    {
        static void Main(string[] args)
        {
            A fc = new A();
            B sc = new B();
            fc.func();
            sc.func();
            Console.ReadKey();
        }
    }
}
