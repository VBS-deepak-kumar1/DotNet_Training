﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo_Constructor
{
   public class Program
    {
        public Program()
        {
            Console.WriteLine("Default Constructor invoked.");
        }
        public static void Main(string[] args)
        {
            Console.WriteLine("Constructor Implementation");
            Program P1 = new Program();
            Program P2 = new Program();
            Program P3 = new Program();
            Console.ReadKey();

        }

    }
   
}
