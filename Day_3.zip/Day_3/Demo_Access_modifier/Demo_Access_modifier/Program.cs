﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Access_modifier
{
    internal class Program:MyClass
    {
        static void Main(string[] args)
        {
            MyClass obj1 = new MyClass();

            //MyClass obj2 = new MyClass();
            obj1.GetInternal();
            obj1.GetProtectedInternal();
            obj1.

        }
    }
}
