﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Destructor_demo
{
    
       public class Employee {
        public Employee()
        {
            Console.WriteLine("Constructor Invoked.");
        }
        ~Employee()
        {
            Console.WriteLine("Destructor Invoked. ");
        }
        static void Main(string[] args)
        {
            Employee E1 = new Employee();
            Employee E2 = new Employee();
            Console.ReadKey();
        }
    }



}
