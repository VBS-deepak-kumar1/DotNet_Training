﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_MainInAnotherClass
{

     class Employee
    {
        public Employee()
        {
            Console.WriteLine("default Constructor Invoked ");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee E1 = new Employee();
            Employee E3 = new Employee();
            Employee E2 = new Employee();
            Console.ReadKey();
        }
    }
}
