﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace First_Space
{
    class Namespace1
    {
        void fun()
        {
            Console.WriteLine("Inside the first Namespace");

        }
    }
    namespace Second_space
    {
        class namspace_2
        {
            public void func()
            {
                Console.WriteLine("inside the second namespace ");
            }
        }
    }
}



namespace Demo_NameSpace
{
    internal class Program
    {
        static void Main(string[] args)
        {
            First_Space.Namespace1 fc = new First_Space.Namespace1();
            First_Space.Second_space.namspace_2 sc = new First_Space.Second_space.namspace_2(); 


        }
    }
}
