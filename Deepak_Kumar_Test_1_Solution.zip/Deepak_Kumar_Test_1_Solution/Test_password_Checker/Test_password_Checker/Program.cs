﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_password_Checker
{
    class Program
    {
        static void Main(string[] args)
        {

            string username, password;
            int count = 0;

            do
            {
                Console.Write("Enter a username: ");
                username = Console.ReadLine();

                Console.Write("Enter a password: ");
                password = Console.ReadLine();

                if (username != "abcd" || password != "1234")
                    count++;
                else
                    count = 1;

            }
            while ((username != "abcd" || password != "1234") && (count != 3));

            if (count == 3)
                Console.WriteLine("wrong password and user details");
            else
                Console.WriteLine("The password entered successfully!");

            Console.ReadKey();
        }


    }
    
}
