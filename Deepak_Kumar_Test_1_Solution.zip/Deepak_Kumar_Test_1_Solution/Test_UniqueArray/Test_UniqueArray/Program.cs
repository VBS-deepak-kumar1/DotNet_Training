﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_UniqueArray
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Length of An Array : ");
            int length = Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[length];
            for (int i = 0; i < length; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }

            for(int i = 0; i < length; i++)
            {
                int count = 0;
                for(int j = 0; j < length; j++)
                {
                    if (arr[i] == arr[j])
                    {
                        count++;
                    }
                    
                }
                if (count == 1)
                {
                    Console.WriteLine("Unique Element is :" + arr[i]);
                }
                if (count > 1)
                {
                    Console.WriteLine("No unique elements are there.");
                }
            }

            Console.ReadKey();


        }
    }
}
