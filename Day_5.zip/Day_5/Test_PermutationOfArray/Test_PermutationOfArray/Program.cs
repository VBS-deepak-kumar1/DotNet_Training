﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_PermutationOfArray
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Length of An Array : ");
            int length = Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[length];
            for (int i = 0; i < length; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.ReadKey();
            void PermutationOfArray()
            {

            }
        }
    }
}
