﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Equality
{
    class Program
    {
        static void Main(string[] args)
        {
            Member Obj1 = new Member { ID = 1, Name="Deepak", Address = "Patna" };
            Member Obj2 = new Member { ID = 1, Name = "Deepak", Address = "Patna" };
            Member Obj3 = Obj1;
            Console.WriteLine("Lets check if two objects have same or unique:");
            Console.WriteLine(Obj1==Obj2);
            Console.WriteLine(Obj1.Equals(Obj2));
            //if object instace are the same or not 
            Console.WriteLine(System.Object.ReferenceEquals(Obj1, Obj2));

            Console.WriteLine(Obj1 == Obj3);
            Console.WriteLine(Obj1.Equals(Obj3));
            //if object instace are the same or not 
            Console.WriteLine(System.Object.ReferenceEquals(Obj1, Obj3));
            Console.WriteLine("structure");
            MyStruct mystruct1 = new MyStruct { name = "deepak",id=1 };
            MyStruct mystruct2 = new MyStruct { id = 1, name = "deepak" };
            Console.WriteLine(System.Object.ReferenceEquals(mystruct1, mystruct1));
            // Console.WriteLine(mystruct2 == mystruct1);
            Console.WriteLine(mystruct1.Equals(mystruct2));
            Console.WriteLine("string...");
            string s1 = "deepak";
            string s2 = "deepak4";
            Console.WriteLine(s1);
            Console.WriteLine(s1.CompareTo(s2));
            Console.WriteLine("Comparing HashCode");
            Obj1 = Obj2;
            Console.WriteLine(Obj1.GetHashCode());
            Console.WriteLine(Obj2.GetHashCode());
           Console.ReadKey();
        }
    }
}
