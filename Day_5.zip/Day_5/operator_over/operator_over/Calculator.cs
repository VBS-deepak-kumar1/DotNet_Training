﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace operator_over
{
    class Calculator
    {
        public int num1, num2;
        public Calculator(int n1, int n2)
            {
            num1=n1;
            num2=n2;
            }

           /* public static Calculator operator -(Calculator c1)
        {
            c1.num1 = -c1.num1;
            c1.num2 = -c1.num2;
            return c1;
        }*/

        public  static Calculator operator+(Calculator cal1,Calculator cal2)
        {
            cal1.num1 = cal1.num1 + cal2.num1;
            cal1.num2 = cal1.num2 + cal2.num2;
            return cal1;
        }
        public void Display()
        {
            Console.WriteLine("num1 is {0} ",this.num1);
            Console.WriteLine("num2 is {0} ", this.num2);

        }

    }
}
