﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace operator_over
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator Cal1 = new Calculator(25, 55);
            Calculator Cal2 = new Calculator(-25,7);
            
            Cal1 = Cal1+Cal2;
            Cal1.Display();
            Console.ReadKey();

            
        }
    }
}
